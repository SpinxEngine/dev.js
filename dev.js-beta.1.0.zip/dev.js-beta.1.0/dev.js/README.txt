You might be wondering how to use this and why is it not a .js file?

1. You have to extend the Engine.html file's code to make your games (with that i mean you have to write your own game code into the html file's code)

2. Both JavaScript and HTML was used to make dev.js!
